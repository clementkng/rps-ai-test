yes
no
YES
nO
blah
No