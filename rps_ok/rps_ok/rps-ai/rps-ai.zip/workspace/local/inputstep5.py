name
rock
no
name
scissors
yes
paper
no